Tileset: the orange/yellow segments on wall are for recognizing the wall jump segmnts
	 the boulder is a breakable tile

Background: BG01 is the default background, goes and repeat in an horizontal axis forever, must be the furthest background
	    BG02 is for cave segments, must be after BG01, BG03 and BG04
	    BG03 is back trees, must e after BG01 and before BG02/04/05
	    BG04 is front trees, must be after BG01/03 and before BG02/05
	    BG05 is building segments (Like lab, bunker, hq, etc) must be after all others

put tileset on front of the backgrounds